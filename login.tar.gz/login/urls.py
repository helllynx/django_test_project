from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^logout/$', views.logout_page),
    url(r'^$', views.home),
    url(r'^register/$', views.register),
    url(r'^register/success/$', views.register_success)
]